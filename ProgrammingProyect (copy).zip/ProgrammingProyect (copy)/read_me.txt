[- - - Guia de uso - - -]

Para poder efectivamente ejecutar el código:
asegúrese de que el directorio de trabajo actual desde el que está ejecutando el cógido
sea el de 'ProgrammingProyect', de lo contrario no podrá ejecutar el código.

Habrán casos en que la interfaz al ejecutarse no funciona o se ve buggeada, en este caso 
mate la ejecución del código y vuelva a repetir el proceso de ejecutarlo. 

Finalmente ejecute y disfrute de la asistencia en diagnóstico que ofrece este sistema :).

[- - - precausiones con los datos - - -]

Esta carpeta contiene los códigos base "diagnosticar.py"
y "infoWin.py" necesarios para ejecutar la ayuda en diagnósico
que ofrece este código, en las carpetas "data" e "imgs" encontrará
bases de datos en formato "csv" para el la primera carpeta y 
en la segunda series de imágenes en formato "png" y "jpg"
***Por favor no los altere sin antes asegurarse de que sabe lo que
está haciendo, en otro caso podría llegar a dañar la funcionalidad
de la solución de código y se vería obligado a reinstalarlo***.


[- - - fuentes y manejo de los datos - - -]

Todas las imágenes usadas y la información que se da sobre síntomas
y diagnóstico están respaldadas con el respectivo link de donde se han 
obtenido y en el caso de la información de deficiencias, esta se encuentra
citada en el documento "Datos Deficiencias Nutricionales.pdf" en la carpeta
'fuentes _ y _ documentación'.


[ - - - disclaimer - - -]

Esta solución implementada en python no pretende ser una guia absoluta 
sobre las deficiencias de las plantas, pretende ser solo orientativa y 
de fines didácticos, para así lograr diagnosticar mejor las plantas, 
los creadores de este cógido no se hacen responsables por las acciones que
se tomen a partir del uso de este código y sus diagnósticos. El uso que se 
de a este cógido es total responsabilidad del usuario.


