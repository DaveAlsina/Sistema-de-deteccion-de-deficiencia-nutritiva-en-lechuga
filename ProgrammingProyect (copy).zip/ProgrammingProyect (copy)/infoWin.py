#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Apr  9 16:24:11 2020

@author: david
"""

import tkinter as tk
import pandas as pd
from PIL import Image 
from os import listdir, getcwd
import re
from unidecode import unidecode




l1 = "*Recuerde, primero ingrese a la carpeta 'ProgrammingProyect' y ejecute desde allí el código* "
l2 = "si se encuentra en el directorio 'ProgrammingProyect' sólo presione ['Enter']:"

path =input(l1+"\n"+l2)

if path == '':
    path= getcwd()+'/'
    print(path)
else:
    path=path
    
data = pd.read_csv(path + 'data/ExtraInfoDiseases.csv')
df = pd.DataFrame(data)
    
diagnosis = [(False, 0.5, 'Nitrogeno'), (True, 0.7333333333333333, 'Azufre'),
             (False, 0.14285714285714285, 'Fósforo'), (False, 0.0, 'Silicio'), 
             (True, 0.75, 'Boro')]


def diagnosisWin(diagnosis):
    #diagnosis looks like this:
    
    #[(False, 0.5, 'Nitrogeno'), (False, 0.3333333333333333, 'Azufre'), 
    #(False, 0.14285714285714285, 'Fósforo'), 
    #(False, 0.0, 'Silicio'), (True, 0.75, 'Boro')]
    
    root_d = tk.Tk()
    root_d.title("Diagnóstico")
    
    
    disease = []
    row=0
#    bcount = 0
    
    ib = createInfoButtons(root_d)
    
    for indx, symp in enumerate(diagnosis):
        
        print(symp,"\t",indx)
        
        if symp[0] == True:
            
            disease.append(symp)
            percentaje = round(symp[1]*100, 2)
            
            label = tk.Label(root_d, 
            text='Detectada deficiencia de {0}, con {1}% de probabilidad'.format(symp[2],percentaje))
            
        
            print(indx)
            
            label.grid(row=row,column=0)
            ib[indx].grid(row=row,column=1)
            
            row += 1
            
    root_d.mainloop()
    
            
            
def createInfoButtons(root):
    
    ib1 = tk.Button(root, text='info', command=lambda: readExtraInfo(0), bg='blue')
    ib2 = tk.Button(root, text='info', command=lambda: readExtraInfo(1), bg='blue')
    ib3 = tk.Button(root, text='info', command=lambda: readExtraInfo(2), bg='blue')
    ib4 = tk.Button(root, text='info', command=lambda: readExtraInfo(3), bg='blue')
    ib5 = tk.Button(root, text='info', command=lambda: readExtraInfo(4), bg='blue')
    ib6 = tk.Button(root, text='info', command=lambda: readExtraInfo(5), bg='blue')
    ib7 = tk.Button(root, text='info', command=lambda: readExtraInfo(6), bg='blue')
    ib8 = tk.Button(root, text='info', command=lambda: readExtraInfo(7), bg='blue')
    ib9 = tk.Button(root, text='info', command=lambda: readExtraInfo(8), bg='blue')
    ib10 = tk.Button(root, text='info', command=lambda: readExtraInfo(9), bg='blue')
    ib11 = tk.Button(root, text='info', command=lambda: readExtraInfo(10), bg='blue')
    ib12 = tk.Button(root, text='info', command=lambda: readExtraInfo(11), bg='blue')
    ib13 = tk.Button(root, text='info', command=lambda: readExtraInfo(12), bg='blue')
    ib14 = tk.Button(root, text='info', command=lambda: readExtraInfo(13), bg='blue')
    ib15 = tk.Button(root, text='info', command=lambda: readExtraInfo(14), bg='blue')
    ib16 = tk.Button(root, text='info', command=lambda: readExtraInfo(15), bg='blue')
    ib17 = tk.Button(root, text='info', command=lambda: readExtraInfo(16), bg='blue')
    ib18 = tk.Button(root, text='info', command=lambda: readExtraInfo(17), bg='blue')
    ib19 = tk.Button(root, text='info', command=lambda: readExtraInfo(18), bg='blue')
    ib20 = tk.Button(root, text='info', command=lambda: readExtraInfo(19), bg='blue')
    ib21 = tk.Button(root, text='info', command=lambda: readExtraInfo(20), bg='blue')
    ib22 = tk.Button(root, text='info', command=lambda: readExtraInfo(21), bg='blue')
    ib23 = tk.Button(root, text='info', command=lambda: readExtraInfo(22), bg='blue')
    ib24 = tk.Button(root, text='info', command=lambda: readExtraInfo(23), bg='blue')
    ib25 = tk.Button(root, text='info', command=lambda: readExtraInfo(24), bg='blue')
    ib26 = tk.Button(root, text='info', command=lambda: readExtraInfo(25), bg='blue')
    ib27 = tk.Button(root, text='info', command=lambda: readExtraInfo(26), bg='blue')
    
    ib = [ib1,ib2,ib3,ib4,ib5,
          ib6,ib7,ib8,ib9,ib10,
          ib11,ib12,ib13,ib14,ib15,
          ib16,ib17,ib18,ib19,ib20,
          ib21,ib22,ib23,ib24,ib25,
          ib26,ib27]
    
    return ib


def readExtraInfo(indx):
    
    rootWin = tk.Tk()
    rootWin.title("Información")
    
    label= tk.Label(rootWin, text= df['extra info'].values[indx])
    print(indx, "en read extra info")
    label.grid(row=1,column=0)
    
    bquit = tk.Button(rootWin, text='mostrar imagen', command=lambda: imgWin(indx), bg='yellow')
    bquit.grid(row = 2, column = 0)
        
    rootWin.mainloop()


def imgWin(i):
    
    matchTxt= df['deficiencia'].values[i] #gets the name of the deficiency
    matchTxt = matchTxt.lower() #lower cases the name
    
    matchTxt = unidecode(matchTxt) #en caso de que el string tenga acentos 
    #lo transforma a la representación ASCII posible más cercana
    
    print(matchTxt)
    
    reg = re.compile( matchTxt + "\_*"+ "\d*"+ "\.*" + "\w+") #creates a regex
    #for finding any images as: "name.[type of img]" 
    #or "name_number.[type of img]" 
    
    
    txt = " ".join(listdir(path+'imgs'))
    #views the folder where the images are storted 
        
    mo = reg.findall(txt) #finds the kind of img with the name of the deficiency
    
    for imgs in mo: 
        img = Image.open(path+'imgs/'+imgs)
        img.show()                  #shows the images
    
    
#   
#diagnosisWin(diagnosis)
