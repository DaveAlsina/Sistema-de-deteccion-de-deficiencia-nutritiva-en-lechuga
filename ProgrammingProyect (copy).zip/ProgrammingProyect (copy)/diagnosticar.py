#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr  7 13:34:59 2020

@author: david
"""
import re
import pandas as pd
import tkinter as tk
from numpy import zeros
import infoWin as iw
from os import getcwd
from PIL import Image

l1 = "*Recuerde, primero ingrese a la carpeta 'ProgrammingProyect' y ejecute desde allí el código* "
l2 = "si se encuentra en el directorio 'ProgrammingProyect' sólo presione ['Enter']:"

path =input(l1+"\n"+l2)

if path == '':
    path= getcwd()+'/'
    print(path)
else:
    path=path



class Defitiency:
    
    """Reads the csv file with symptoms data"""
    
    
    def __init__(self, root):
        
        data = pd.read_csv(path + 'data/' +'sintomas.csv')  #reads the csv and stores the readings into data
        self.df = pd.DataFrame(data)    #creates a pd dataframe based on data
        self.df = self.df.fillna(0)     #fills the NaN values with 0
        self.root = root                #takes the tk window and assigns it as an attribute
        self.createButtons()
        self.diseaseButton()
        self.createLeftLabels()
        self.createRightLabels()
        
#        print(data.iloc[1][2])
#        print(len(data.iloc[1]),"\n\n")
        
        
    def diseaseButton(self):
        number = re.compile('\d+')    #creates a object that matches numbers
        defitiency =[]  #creates a lists where the digit matches can be storted
        
        
        data = pd.read_csv(path + 'data/' + 'deficiencia_items.csv') #reads the csv file
        df = pd.DataFrame(data) #converts it into a pandas df
        
        #print(df['Deficiencia'].values)
        #print(df['items'].values)
        
        for i in df['items'].values:        #gets the values of the columm 'items'
                                            #which are a series of strings in a list 
                                            #that look like this: ['0, 9, 10, 4', ... ,'12 ,13']
                                            
            defitiency.append(number.findall(i))  #finds all the digits and appends the match to 
                                                #defitiency
        
        def toInt(x):   #converts the match list to list of integers
            
            new=[]  #list where the converted to int elements of the subsets are stored 
            final=[] #list where the subsets converted to int are storted
            
            for Set in x:               #access the lists in the list
                
                for element in Set:     #access the elements in the list
                    new.append(int(element))    #appends the converted element to the list
                                
                final.append(new)       #appends the converted new lists to the final list
                new=[]                  #resets new in order to be able to store the other lists
                
            return final                #gives the converted list of lists 
        
        
        
        
        
        defitiency = toInt(defitiency)  #list of strings is converted to list of lists of integers
        #print(defitiency)
        
        df = pd.DataFrame(list(zip(df['Deficiencia'].values, defitiency)),
                          columns= ['defitiency','buttons']) #actualices the data frame
                     #with the values of the new defitiency list and the same labels
        #print(df)
        self.df_Disease = df
        return self.df_Disease
        
        
        
    def monitorButtons(self,index):
        
        if self.buttonStates[index] == 0:       #if the index was originally 0
            self.b[index].configure(bg='red')   #changes the button color to red
            self.buttonStates[index] = 1        #changes the button state value to 1
            
        else:                                   #if the index was originally 1
            self.b[index].configure(bg='blue')  #restores the button color to blue
            self.buttonStates[index] = 0        #restores the button state value to 0
                   
     


         
        
    def createLeftLabels(self):
        buttonIndex=0   #counts in what button index we're in in order
                        #to not repeat button use
                        
        row=0           #counts the row we're in when applying grid
        
                
        for col,coln in zip(self.df.columns[1:],range(len(self.df.columns[1:]))):
        
            if coln%2 == 0:      #only for even index columns
                
                label = tk.Label(self.root,text=col, fg = 'blue')  #creates a label for
                                                                   #the column symptom label
                label.grid(row=row,column=0)    #applies the label to the user interface
                row +=1                       #increments the row counter by one
                                            #just when the label is plotted to the interface
                
                
                
                for s in self.df[col]:  #gets the values inside every column
                    
                    
                                    
                    if type(s)==str:    #prooves if the sympt in the column is a valid one
                                        #or a empty space NaN or Zero
                        
                        label = tk.Label(self.root,text=s)  #creates a label for the valid symptom
                        label.grid(row=row,column=0)    #puts the label in the interface
                        
                        self.b[buttonIndex].grid(row=row, column=1) #adds a button next to the label
                        
                        row +=1            #increases the row counter
                        buttonIndex += 1    #increases the button counter 
                
                
                separator = tk.Label(self.root,text='- - -')    #creates a separator label
                                                                #for stetic reasons
                separator.grid(row=row,column=0)                #appends it just below the last
                                                                #label that was added
                row +=1                             #increases the row count by 1
                
        self.buttonIndex = buttonIndex   #stores the actual remaining buttons
                                         #indicated by the index
                
      
        
        
        
    def createRightLabels(self):
        
        buttonIndex= self.buttonIndex   #counts in what button index we're in in order
                        #to not repeat button use
                        
        row=0           #counts the row we're in when applying grid
        
                
        for col,coln in zip(self.df.columns[1:],range(len(self.df.columns[1:]))):
        
            if coln%2 != 0:      #only for odd index columns
                
                label = tk.Label(self.root,text=col, fg = 'blue')  #creates a label for
                                                                   #the column symptom label
                label.grid(row=row,column=3)    #applies the label to the user interface
                row +=1                       #increments the row counter by one
                                            #just when the label is plotted to the interface
                
                
                
                for s in self.df[col]:  #gets the values inside every column
                    
                    
                                    
                    if type(s)==str:    #prooves if the sympt in the column is a valid one
                                        #or a empty space NaN or Zero
                        
                        label = tk.Label(self.root,text=s)  #creates a label for the valid symptom
                        label.grid(row=row,column=3)    #puts the label in the interface
                        
                        self.b[buttonIndex].grid(row=row, column=4) #adds a button next to the label
                        
                        row +=1            #increases the row counter
                        buttonIndex += 1    #increases the button counter 
                
                
                separator = tk.Label(self.root,text='- - -')#creates a separator label
                                                            #for stetic reasons
                separator.grid(row=row,column=3)   #applies the label to the user interface
                row +=1                           #increments the row counter by one
                                         #just when the label is plotted to the interface
        
        
    def makeDiagnosis(self):
        diagnosis = []
        result=0
        
        for buttonList in self.df_Disease['buttons']:      
            
            for button in buttonList:
                result += self.buttonStates[button] #sums the values 
                
            result = result/len(buttonList) #gets the mean 
            diagnosis.append(result)    #appends the mean to the lists and resets result val
            result = 0
        
        r = map(lambda data: (data[1]>0.7, data[1], self.df_Disease['defitiency'][data[0]])
        , enumerate(diagnosis)) #the iterable is a tuple given by enumerate (index,value)
                                #lambda takes the tuple compares if one of the values
                                #is greater than 70%, puts the number of % next to it
                                #and finally adds the corresponding label of disease
                                #('True/False', 'x %', 'label')
        self.r = list(r)
                
    
    def graphicGuide(self):
        img = Image.open(path+'imgs/'+'guia.png')
        img2 = Image.open(path+'imgs/'+'guia_2.png')
        img.show()  
        img2.show()                 
        
        
    def createButtons(self):
        b1 = tk.Button(root, text='', command=lambda: self.monitorButtons(0) , bg='blue')
        b2 = tk.Button(root, text='', command=lambda: self.monitorButtons(1) , bg='blue')
        b3 = tk.Button(root, text='', command=lambda: self.monitorButtons(2) , bg='blue')
        b4 = tk.Button(root, text='', command=lambda: self.monitorButtons(3) , bg='blue')
        b5 = tk.Button(root, text='', command=lambda: self.monitorButtons(4), bg='blue')
        b6 = tk.Button(root, text='', command=lambda: self.monitorButtons(5), bg='blue')
        b7 = tk.Button(root, text='', command=lambda: self.monitorButtons(6), bg='blue')
        b8 = tk.Button(root, text='', command=lambda: self.monitorButtons(7) , bg='blue')
        b9 = tk.Button(root, text='', command=lambda: self.monitorButtons(8), bg='blue')
        b10 = tk.Button(root, text='', command=lambda: self.monitorButtons(9) , bg='blue')
        b11 = tk.Button(root, text='', command=lambda: self.monitorButtons(10), bg='blue')
        b12 = tk.Button(root, text='', command=lambda: self.monitorButtons(11), bg='blue')
        b13 = tk.Button(root, text='', command=lambda: self.monitorButtons(12), bg='blue')
        b14 = tk.Button(root, text='', command=lambda: self.monitorButtons(13) , bg='blue')
        b15 = tk.Button(root, text='', command=lambda: self.monitorButtons(14), bg='blue')
        b16 = tk.Button(root, text='', command=lambda: self.monitorButtons(15), bg='blue')
        b17 = tk.Button(root, text='', command=lambda: self.monitorButtons(16), bg='blue')
        b18 = tk.Button(root, text='', command=lambda: self.monitorButtons(17), bg='blue')
        b19 = tk.Button(root, text='', command=lambda: self.monitorButtons(18), bg='blue')
        b20 = tk.Button(root, text='', command=lambda: self.monitorButtons(19), bg='blue')
        b21 = tk.Button(root, text='', command=lambda: self.monitorButtons(20), bg='blue')
        b22 = tk.Button(root, text='', command=lambda: self.monitorButtons(21), bg='blue')
        b23 = tk.Button(root, text='', command=lambda: self.monitorButtons(22), bg='blue')
        b24 = tk.Button(root, text='', command=lambda: self.monitorButtons(23), bg='blue')
        b25 = tk.Button(root, text='', command=lambda: self.monitorButtons(24), bg='blue')
        b26 = tk.Button(root, text='', command=lambda: self.monitorButtons(25), bg='blue')
        b27 = tk.Button(root, text='', command=lambda: self.monitorButtons(26), bg='blue')
        b28 = tk.Button(root, text='', command=lambda: self.monitorButtons(27), bg='blue')
        b29 = tk.Button(root, text='', command=lambda: self.monitorButtons(28), bg='blue')
        b30 = tk.Button(root, text='', command=lambda: self.monitorButtons(29), bg='blue')
        b31 = tk.Button(root, text='', command=lambda: self.monitorButtons(30), bg='blue')
        b32 = tk.Button(root, text='', command=lambda: self.monitorButtons(31), bg='blue')
        b33 = tk.Button(root, text='', command=lambda: self.monitorButtons(32), bg='blue')
        
        
        bd = tk.Button(root, text='Diagnosticar', command=self.root.destroy, bg='orange')
        bd.grid(row=30,column=2)
        
        gb = tk.Button(root, text='Guia gráfica', command=self.graphicGuide, bg='yellow')
        gb.grid(row=28,column=2)
    
        self.b = [b1,b2,b3,b4,b5,
                  b6,b7,b8,b9,b10,
                  b11,b12,b13,b14,b15,
                  b16,b17,b18,b19,b20,
                  b21,b22,b23,b24,b25,
                  b26,b27,b28,b29,b30,
                  b31,b32,b33]
            
            
        self.buttonStates = zeros(len(self.b))
        
        
    def __str__(self):
        return "Diagnosis after all the process is: "+ "\n"+ str(self.r)
            
            
            
        
root= tk.Tk()
root.title("Sistema de ayuda en detección de deficiecias nutritivas en plantas")
d = Defitiency(root)

root.mainloop()

d.makeDiagnosis()   #hace el diagnóstico de la planta 

iw.diagnosisWin(d.r) #el resultado del dignósitco se lo pasa a diagnosisWin 
                     #que crea una ventana de interacción para poder ver los diagnósticos